--------------------------------------------------------------X------------------------------------------------------------------------
To run both "EDA & Model SCRIPT.ipynb" and "Visualizations.ipynb" file, we would need to use the Jypyter Nootbook platform.  

Some of the necessary libraries to run these files are,
- numpy
- pandas
- seaborn
- matplotlib
- sklearn
- xgboost
- optuna
- SMOTE

Link of the dataset:
https://www.kaggle.com/datasets/saadharoon27/hr-analytics-dataset?resource=download
--------------------------------------------------------------X------------------------------------------------------------------------